export const environment = {
  production: true,
  domain : "http://localhost:4200",
  apiURL : "http://5.161.52.230:8877"
};
